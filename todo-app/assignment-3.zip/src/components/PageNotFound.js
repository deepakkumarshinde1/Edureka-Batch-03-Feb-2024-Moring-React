const PageNotFound = () => {
  return (
    <center>
      <h1> Page Not Found</h1>
    </center>
  );
};

export default PageNotFound;
